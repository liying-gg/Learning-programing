#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define __USE_GNU
#include <ucontext.h>
#include <signal.h>
#include <errno.h>
static void seghandler (unsigned int sn , siginfo_t  *si , struct ucontext *sc)
{
   long long rip;
   int i;
   char string[2048];
   rip=(long long)(sc->uc_mcontext.gregs[REG_RIP]);
   psiginfo(si,string);
   printf(" Signal number = %d, Signal errno = %d\n",
            si->si_signo,si->si_errno);

   /*Different kind of signal has different si_code representation*/
   switch(si->si_code)
   {
    case 1: printf(" SI code = %d (Address not mapped to object)\n",
               si->si_code);
              break;
    case 2: printf(" SI code = %d (Invalid permissions for \
                        mapped object)\n",si->si_code);
            break;
    default: printf("SI code = %d (Unknown SI Code)\n",si->si_code);
             break;
   }
  printf(" Intruction pointer = 0x%llx \n",rip);
  printf(" Fault addr = 0x%llx \n",(long long)si->si_addr);

  printf("***GPR values are the time of fault*** \n");
  printf(" REG_R8 = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_R8]);
  printf(" REG_R9 = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_R9]);
  printf(" REG_R10 = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_R10]);
  printf(" REG_R11 = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_R11]);
  printf(" REG_R12 = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_R12]);
  printf(" REG_R13 = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_R13]);
  printf(" REG_R14 = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_R14]);
  printf(" REG_R15 = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_R15]);
  printf(" REG_RDI = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_RDI]);
  printf(" REG_RSI = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_RSI]);
  printf(" REG_RBP = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_RBP]);
  printf(" REG_RBX = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_RBX]);
  printf(" REG_RDX = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_RDX]);
  printf(" REG_RAX = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_RAX]);
  printf(" REG_RCX = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_RCX]);
  printf(" REG_RSP = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_RSP]);
  printf(" REG_RIP = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_RIP]);
  printf(" REG_EFL = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_EFL]);
  printf(" REG_CSGSFS = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_CSGSFS]);
  printf(" REG_ERR = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_ERR]);
  printf(" REG_TRAPNO = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_TRAPNO]);
  printf(" REG_OLDMASK = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_OLDMASK]);
  printf(" REG_CR2 = 0x%llx \n", (long long)sc->uc_mcontext.gregs[REG_CR2]);

  exit (0);
}

main()
{
   struct sigaction m;
   char *p,*q, arr[]="Ma";
   q=arr;
   p=(char *)0x1000;
   m.sa_flags = SA_SIGINFO;
   m.sa_sigaction = (void *)seghandler;
   sigaction (SIGSEGV,&m,(struct sigaction *)NULL);
   *p++ = *q++;
   return 0;
}
